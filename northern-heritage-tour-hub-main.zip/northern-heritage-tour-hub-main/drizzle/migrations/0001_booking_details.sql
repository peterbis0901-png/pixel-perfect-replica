alter table public.booking_requests
  add column email text check (email is null or char_length(email) <= 255),
  add column adults int not null default 1 check (adults between 0 and 50),
  add column children_5_10 int not null default 0 check (children_5_10 between 0 and 50),
  add column children_2_5 int not null default 0 check (children_2_5 between 0 and 50),
  add column infants int not null default 0 check (infants between 0 and 50),
  add column single_rooms int not null default 0 check (single_rooms between 0 and 50),
  add column total_vnd bigint,
  add column payment_method text check (payment_method is null or payment_method in ('bank_transfer','cash')),
  add column notes text check (notes is null or char_length(notes) <= 1000),
  add column source text not null default 'contact' check (source in ('contact','booking'));

create or replace function public.assign_first_admin()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if lower(new.email) = 'peterbis0901@gmail.com' then
    insert into public.user_roles (user_id, role) values (new.id, 'admin') on conflict do nothing;
  end if;
  return new;
end $$;