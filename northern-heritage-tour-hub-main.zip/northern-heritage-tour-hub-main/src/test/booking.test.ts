import { describe, it, expect } from "vitest";
import { totalPrice, deposit, nextThursdays } from "@/lib/booking";

const none = { adults: 0, children_5_10: 0, children_2_5: 0, infants: 0, single_rooms: 0 };

describe("booking pricing", () => {
  it("adult costs 5,560,000", () => expect(totalPrice({ ...none, adults: 1 })).toBe(5_560_000));
  it("child 5-10 costs 4,170,000", () => expect(totalPrice({ ...none, children_5_10: 1 })).toBe(4_170_000));
  it("child 2-5 costs 2,780,000", () => expect(totalPrice({ ...none, children_2_5: 1 })).toBe(2_780_000));
  it("under 2 is free", () => expect(totalPrice({ ...none, infants: 2 })).toBe(0));
  it("single room adds 1,600,000", () => expect(totalPrice({ ...none, adults: 1, single_rooms: 1 })).toBe(7_160_000));
  it("deposit is 50%", () => expect(deposit(11_120_000)).toBe(5_560_000));
  it("departures are Thursdays at least 7 days out", () => {
    const from = new Date(2026, 9, 25); // Sun 25 Oct 2026
    expect(nextThursdays(2, from)).toEqual(["2026-11-05", "2026-11-12"]);
  });
});
