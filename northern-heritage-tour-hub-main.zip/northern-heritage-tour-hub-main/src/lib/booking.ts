// Prices in VND, from the tour pricing table.
export const PRICES = {
  adult: 5_560_000, // adults & children 10+
  child5to10: 4_170_000, // 75%
  child2to5: 2_780_000, // 50%
  infant: 0, // under 2
  singleRoom: 1_600_000,
};
export const DEPOSIT_RATE = 0.5;

export type Party = { adults: number; children_5_10: number; children_2_5: number; infants: number; single_rooms: number };

export function totalPrice(p: Party) {
  return (
    p.adults * PRICES.adult +
    p.children_5_10 * PRICES.child5to10 +
    p.children_2_5 * PRICES.child2to5 +
    p.infants * PRICES.infant +
    p.single_rooms * PRICES.singleRoom
  );
}

export const deposit = (total: number) => Math.round(total * DEPOSIT_RATE);

/** Next n Thursdays (tour departs every Thursday), at least 7 days from `from`. */
export function nextThursdays(n: number, from = new Date()) {
  const d = new Date(Date.UTC(from.getFullYear(), from.getMonth(), from.getDate() + 7));
  while (d.getUTCDay() !== 4) d.setUTCDate(d.getUTCDate() + 1);
  return Array.from({ length: n }, (_, i) => {
    const x = new Date(d);
    x.setUTCDate(d.getUTCDate() + i * 7);
    return x.toISOString().slice(0, 10);
  });
}

export const vnd = (n: number) => n.toLocaleString("vi-VN") + "₫";

// Placeholder bank details — replace with the real account.
export const BANK = {
  bank: "Vietcombank",
  account: "0000 0000 0000",
  holder: "CONG TY CO PHAN DAU CHAN VIET",
};
