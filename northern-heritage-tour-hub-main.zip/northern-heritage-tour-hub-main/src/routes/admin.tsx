import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin · Booking requests | Heritage Journey" },
      { name: "description", content: "Private admin view for reviewing tour booking requests." },
      { property: "og:title", content: "Admin · Booking requests" },
      { property: "og:description", content: "Private admin view for tour booking requests." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: AdminPage,
});

type Booking = {
  id: string; name: string; phone: string; guests: number | null;
  departure_date: string | null; lang: string; status: string; created_at: string;
  email: string | null; adults: number; children_5_10: number; children_2_5: number; infants: number;
  single_rooms: number; total_vnd: number | null; payment_method: string | null; notes: string | null; source: string;
};
const STATUSES = ["new", "contacted", "confirmed", "cancelled"];
const input = "w-full rounded-lg border border-input bg-background px-4 py-3 text-sm text-foreground outline-none focus:border-primary";

function AdminPage() {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) { setIsAdmin(null); return; }
    supabase.rpc("has_role", { _user_id: session.user.id, _role: "admin" }).then(({ data }) => setIsAdmin(!!data));
  }, [session]);

  return (
    <div className="min-h-screen bg-secondary px-5 py-12 font-sans text-foreground">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
          <div>
            <a href="/" className="font-display text-xl font-bold text-primary">Di Sản<span className="text-accent"> · </span>Heritage</a>
            <h1 className="mt-2 font-display text-4xl font-semibold text-primary">Booking requests</h1>
          </div>
          {session && (
            <button onClick={() => supabase.auth.signOut()} className="rounded-full border border-primary px-5 py-2 text-sm font-semibold text-primary hover:bg-primary hover:text-primary-foreground">Sign out</button>
          )}
        </div>
        {!ready ? null : !session ? <AuthForm /> : isAdmin === null ? <p>Loading…</p> : !isAdmin ? (
          <p className="rounded-2xl bg-card p-8">This account doesn't have admin access.</p>
        ) : <Bookings />}
      </div>
    </div>
  );
}

function AuthForm() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault(); setBusy(true); setMsg("");
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password: pw });
      if (error) setMsg(error.message);
    } else {
      const { data, error } = await supabase.auth.signUp({ email, password: pw, options: { emailRedirectTo: `${window.location.origin}/admin` } });
      if (error) setMsg(error.message);
      else if (!data.session) setMsg("Check your email to confirm your account, then sign in.");
    }
    setBusy(false);
  };
  return (
    <form onSubmit={submit} className="mx-auto max-w-sm space-y-3 rounded-2xl bg-card p-8 shadow-glow">
      <h2 className="font-display text-2xl font-semibold text-primary">{mode === "in" ? "Admin sign in" : "Create admin account"}</h2>
      <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className={input} />
      <input required type="password" minLength={6} value={pw} onChange={(e) => setPw(e.target.value)} placeholder="Password" className={input} />
      {msg && <p className="text-sm text-muted-foreground">{msg}</p>}
      <button disabled={busy} className="w-full rounded-full bg-accent py-3 font-semibold text-accent-foreground disabled:opacity-60">{mode === "in" ? "Sign in" : "Sign up"}</button>
      <button type="button" onClick={() => setMode(mode === "in" ? "up" : "in")} className="w-full text-sm text-primary underline">
        {mode === "in" ? "First time? Create the admin account" : "Already have an account? Sign in"}
      </button>
    </form>
  );
}

function Bookings() {
  const [rows, setRows] = useState<Booking[] | null>(null);
  const load = () => supabase.from("booking_requests").select("*").order("created_at", { ascending: false }).then(({ data }) => setRows((data as Booking[]) ?? []));
  useEffect(() => { load(); }, []);
  const setStatus = async (id: string, status: string) => {
    await supabase.from("booking_requests").update({ status }).eq("id", id);
    load();
  };
  if (!rows) return <p>Loading…</p>;
  if (!rows.length) return <p className="rounded-2xl bg-card p-8 text-muted-foreground">No booking requests yet.</p>;
  return (
    <div className="overflow-x-auto rounded-2xl border border-border bg-card">
      <table className="w-full text-left text-sm">
        <thead className="bg-primary text-primary-foreground">
          <tr>{["Received", "Type", "Traveler", "Departure", "Party", "Total / payment", "Notes", "Status"].map((h) => <th key={h} className="px-4 py-3 font-semibold">{h}</th>)}</tr>
        </thead>
        <tbody className="divide-y divide-border">
          {rows.map((r) => (
            <tr key={r.id}>
              <td className="px-4 py-3 text-muted-foreground">{new Date(r.created_at).toLocaleString()}</td>
              <td className="px-4 py-3 capitalize">{r.source}</td>
              <td className="px-4 py-3"><p className="font-semibold">{r.name}</p><a href={`tel:${r.phone}`} className="text-primary underline">{r.phone}</a>{r.email && <p className="text-muted-foreground">{r.email}</p>}</td>
              <td className="px-4 py-3">{r.departure_date ?? "—"}</td>
              <td className="px-4 py-3 text-xs">{r.source === "booking" ? <>{r.adults} adult · {r.children_5_10} child 5–10 · {r.children_2_5} child 2–5 · {r.infants} infant{r.single_rooms ? ` · ${r.single_rooms} single` : ""}</> : `${r.guests ?? "—"} guests`}</td>
              <td className="px-4 py-3">{r.total_vnd != null ? <p className="font-semibold">{r.total_vnd.toLocaleString("vi-VN")}₫</p> : "—"}<p className="text-xs text-muted-foreground">{r.payment_method === "bank_transfer" ? "Bank transfer" : r.payment_method === "cash" ? "Cash" : ""} · {r.lang.toUpperCase()}</p></td>
              <td className="max-w-48 px-4 py-3 text-xs">{r.notes ?? "—"}</td>
              <td className="px-4 py-3">
                <select value={r.status} onChange={(e) => setStatus(r.id, e.target.value)} className="rounded-lg border border-input bg-background px-2 py-1">
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
