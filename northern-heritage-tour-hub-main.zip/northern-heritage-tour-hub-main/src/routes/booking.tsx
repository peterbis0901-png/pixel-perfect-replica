import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState, type FormEvent } from "react";
import { LangProvider, useLang } from "@/lib/i18n";
import { supabase } from "@/integrations/supabase/client";
import { BANK, PRICES, deposit, nextThursdays, totalPrice, vnd, type Party } from "@/lib/booking";

export const Route = createFileRoute("/booking")({
  head: () => ({
    meta: [
      { title: "Đặt tour · Book the Heritage Journey Hà Nội – Ninh Bình – Hạ Long" },
      { name: "description", content: "Chọn ngày khởi hành, số khách và thanh toán đặt cọc. Choose your Thursday departure, travelers and deposit payment." },
      { property: "og:title", content: "Book the Heritage Journey: Hanoi – Ninh Binh – Ha Long" },
      { property: "og:description", content: "Pick a Thursday departure, add travelers and see your total and deposit instantly." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: () => (
    <LangProvider>
      <BookingPage />
    </LangProvider>
  ),
});

const l = (vi: string, en: string) => ({ vi, en });
const T = {
  back: l("← Về trang tour", "← Back to tour"),
  title: l("Đặt tour", "Book your tour"),
  sub: l("Hà Nội – Ninh Bình – Hạ Long · 4 ngày 3 đêm · Khởi hành thứ Năm", "Hanoi – Ninh Binh – Ha Long · 4 days 3 nights · Thursday departures"),
  s1: l("1. Ngày khởi hành", "1. Departure date"),
  s2: l("2. Số khách", "2. Travelers"),
  s3: l("3. Thông tin liên hệ", "3. Contact details"),
  s4: l("4. Thanh toán", "4. Payment"),
  adults: l("Người lớn & trẻ từ 10 tuổi", "Adults & children 10+"),
  c510: l("Trẻ em 5 – 10 tuổi", "Children 5–10"),
  c25: l("Trẻ em 2 – 5 tuổi", "Children 2–5"),
  inf: l("Trẻ em dưới 2 tuổi", "Children under 2"),
  single: l("Phòng đơn (phụ thu)", "Single rooms (supplement)"),
  name: l("Họ và tên", "Full name"),
  phone: l("Số điện thoại", "Phone number"),
  email: l("Email (không bắt buộc)", "Email (optional)"),
  notes: l("Ghi chú (ăn chay, yêu cầu đặc biệt…)", "Notes (vegetarian, special requests…)"),
  bank: l("Chuyển khoản ngân hàng", "Bank transfer"),
  cash: l("Tiền mặt tại văn phòng", "Cash at our office"),
  bankInfo: l("Chuyển khoản tiền cọc tới:", "Transfer the deposit to:"),
  ref: l("Nội dung: Họ tên + số điện thoại", "Reference: your name + phone number"),
  policy: l("Đặt cọc 50% khi đăng ký, thanh toán phần còn lại trước ngày khởi hành 7 ngày.", "50% deposit on booking; balance due 7 days before departure."),
  total: l("Tổng cộng", "Total"),
  dep: l("Đặt cọc 50%", "50% deposit"),
  submit: l("Gửi đặt tour", "Submit booking"),
  noGuests: l("Vui lòng chọn ít nhất 1 người lớn.", "Please add at least 1 adult."),
  fail: l("Chưa gửi được. Vui lòng kiểm tra thông tin hoặc gọi hotline.", "Couldn't send. Please check your details or call us."),
  done: l("Cảm ơn bạn! Chúng tôi đã nhận yêu cầu đặt tour và sẽ liên hệ xác nhận sớm.", "Thank you! We've received your booking and will contact you to confirm soon."),
};

const box = "rounded-2xl border border-border bg-card p-6 md:p-8";
const input = "w-full rounded-lg border border-input bg-background px-4 py-3 text-sm text-foreground outline-none focus:border-primary";
const h3 = "mb-5 font-display text-2xl font-semibold text-primary";

function Counter({ label, price, value, onChange }: { label: string; price: string; value: number; onChange: (n: number) => void }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-border py-3 last:border-0">
      <div><p className="font-semibold">{label}</p><p className="text-xs text-muted-foreground">{price}</p></div>
      <div className="flex items-center gap-3">
        <button type="button" onClick={() => onChange(Math.max(0, value - 1))} className="h-9 w-9 rounded-full border border-primary text-primary hover:bg-primary hover:text-primary-foreground" aria-label="-">−</button>
        <span className="w-6 text-center font-semibold">{value}</span>
        <button type="button" onClick={() => onChange(Math.min(50, value + 1))} className="h-9 w-9 rounded-full border border-primary text-primary hover:bg-primary hover:text-primary-foreground" aria-label="+">+</button>
      </div>
    </div>
  );
}

function BookingPage() {
  const { lang, setLang, t } = useLang();
  const dates = useMemo(() => nextThursdays(12), []);
  const [date, setDate] = useState("");
  const [party, setParty] = useState<Party>({ adults: 2, children_5_10: 0, children_2_5: 0, infants: 0, single_rooms: 0 });
  const [c, setC] = useState({ name: "", phone: "", email: "", notes: "" });
  const [pay, setPay] = useState<"bank_transfer" | "cash">("bank_transfer");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [done, setDone] = useState(false);
  const total = totalPrice(party);
  const set = (k: keyof Party) => (n: number) => setParty({ ...party, [k]: n });
  const fmtDate = (d: string) => new Date(d + "T00:00:00").toLocaleDateString(lang === "vi" ? "vi-VN" : "en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (party.adults < 1) return setErr(t(T.noGuests));
    setBusy(true); setErr("");
    const guests = party.adults + party.children_5_10 + party.children_2_5 + party.infants;
    const { error } = await supabase.from("booking_requests").insert({
      source: "booking", name: c.name.trim(), phone: c.phone.trim(), email: c.email.trim() || null,
      notes: c.notes.trim() || null, departure_date: date, guests, ...party,
      total_vnd: total, payment_method: pay, lang,
    });
    setBusy(false);
    if (error) setErr(t(T.fail)); else { setDone(true); window.scrollTo({ top: 0 }); }
  };

  return (
    <div className="min-h-screen bg-secondary px-5 py-10 font-sans text-foreground">
      <div className="mx-auto max-w-5xl">
        <div className="mb-8 flex items-center justify-between gap-4">
          <a href="/" className="text-sm font-semibold text-primary hover:underline">{t(T.back)}</a>
          <div className="flex rounded-full border border-border bg-background p-1 text-xs font-semibold" role="group" aria-label="Language">
            {(["vi", "en"] as const).map((x) => (
              <button key={x} onClick={() => setLang(x)} aria-pressed={lang === x}
                className={`rounded-full px-3 py-1 uppercase ${lang === x ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-primary"}`}>{x}</button>
            ))}
          </div>
        </div>
        <p className="mb-3 text-xs font-semibold uppercase tracking-[0.25em] text-accent">Di Sản · Heritage</p>
        <h1 className="font-display text-5xl font-semibold text-primary">{t(T.title)}</h1>
        <p className="mt-3 text-muted-foreground">{t(T.sub)}</p>

        {done ? (
          <div className={`${box} mt-10 text-center`}>
            <p className="font-display text-3xl text-primary">{t(T.done)}</p>
            {pay === "bank_transfer" && (
              <p className="mt-6 text-sm">{t(T.bankInfo)} <b>{BANK.bank} · {BANK.account} · {BANK.holder}</b> — {t(T.dep)}: <b>{vnd(deposit(total))}</b></p>
            )}
          </div>
        ) : (
          <form onSubmit={submit} className="mt-10 grid gap-6 lg:grid-cols-[1fr_340px]">
            <div className="space-y-6">
              <section className={box}>
                <h3 className={h3}>{t(T.s1)}</h3>
                <select required value={date} onChange={(e) => setDate(e.target.value)} className={input}>
                  <option value="" disabled>—</option>
                  {dates.map((d) => <option key={d} value={d}>{fmtDate(d)}</option>)}
                </select>
              </section>
              <section className={box}>
                <h3 className={h3}>{t(T.s2)}</h3>
                <Counter label={t(T.adults)} price={vnd(PRICES.adult)} value={party.adults} onChange={set("adults")} />
                <Counter label={t(T.c510)} price={vnd(PRICES.child5to10)} value={party.children_5_10} onChange={set("children_5_10")} />
                <Counter label={t(T.c25)} price={vnd(PRICES.child2to5)} value={party.children_2_5} onChange={set("children_2_5")} />
                <Counter label={t(T.inf)} price={lang === "vi" ? "Miễn phí" : "Free"} value={party.infants} onChange={set("infants")} />
                <Counter label={t(T.single)} price={`+${vnd(PRICES.singleRoom)}`} value={party.single_rooms} onChange={set("single_rooms")} />
              </section>
              <section className={`${box} space-y-3`}>
                <h3 className={h3}>{t(T.s3)}</h3>
                <input required maxLength={120} value={c.name} onChange={(e) => setC({ ...c, name: e.target.value })} placeholder={t(T.name)} className={input} />
                <div className="grid gap-3 sm:grid-cols-2">
                  <input required type="tel" minLength={5} maxLength={30} value={c.phone} onChange={(e) => setC({ ...c, phone: e.target.value })} placeholder={t(T.phone)} className={input} />
                  <input type="email" maxLength={255} value={c.email} onChange={(e) => setC({ ...c, email: e.target.value })} placeholder={t(T.email)} className={input} />
                </div>
                <textarea maxLength={1000} rows={3} value={c.notes} onChange={(e) => setC({ ...c, notes: e.target.value })} placeholder={t(T.notes)} className={input} />
              </section>
              <section className={`${box} space-y-3`}>
                <h3 className={h3}>{t(T.s4)}</h3>
                {(["bank_transfer", "cash"] as const).map((m) => (
                  <label key={m} className={`flex cursor-pointer items-center gap-3 rounded-lg border p-4 ${pay === m ? "border-primary bg-secondary" : "border-border"}`}>
                    <input type="radio" name="pay" checked={pay === m} onChange={() => setPay(m)} className="accent-primary" />
                    <span className="font-semibold">{t(m === "bank_transfer" ? T.bank : T.cash)}</span>
                  </label>
                ))}
                {pay === "bank_transfer" && (
                  <div className="rounded-lg bg-secondary p-4 text-sm">
                    <p className="mb-2 font-semibold">{t(T.bankInfo)}</p>
                    <p>{BANK.bank}</p><p className="font-display text-xl font-semibold text-primary">{BANK.account}</p><p>{BANK.holder}</p>
                    <p className="mt-2 text-muted-foreground">{t(T.ref)}</p>
                  </div>
                )}
                <p className="text-xs text-muted-foreground">{t(T.policy)}</p>
              </section>
            </div>
            <aside className="h-fit rounded-2xl bg-primary p-6 text-primary-foreground shadow-glow lg:sticky lg:top-6">
              <p className="text-xs uppercase tracking-widest text-gold">{t(T.total)}</p>
              <p className="mt-2 font-display text-4xl font-semibold">{vnd(total)}</p>
              <p className="mt-4 text-sm opacity-80">{t(T.dep)}</p>
              <p className="font-display text-2xl font-semibold text-gold">{vnd(deposit(total))}</p>
              {date && <p className="mt-4 text-sm opacity-80">{fmtDate(date)}</p>}
              {err && <p className="mt-4 rounded-lg bg-card p-3 text-sm text-destructive">{err}</p>}
              <button disabled={busy} className="mt-6 w-full rounded-full bg-accent py-3.5 font-semibold text-accent-foreground disabled:opacity-60">{t(T.submit)}</button>
            </aside>
          </form>
        )}
      </div>
    </div>
  );
}
