import { createFileRoute } from "@tanstack/react-router";
import { createOpenAI } from "@ai-sdk/openai";
import { streamText, type ModelMessage } from "ai";
import * as C from "@/lib/tour-content";
import {
  createLovableAiGatewayRunIdFetch,
  getLovableAiGatewayRunId,
  withLovableAiGatewayRunIdHeader,
} from "@/lib/ai/run-id";

const MODEL = "openai/gpt-6-astra";

function instructions(lang: string) {
  const facts = {
    hero: C.hero,
    overview: C.overview,
    itinerary: C.days,
    pricing: C.pricing,
    policies: C.policies,
    faq: C.faq,
    contact: C.contact,
  };
  return `You are the friendly tour assistant for the "Heritage Journey: Hà Nội – Ninh Bình – Hạ Long" 4-day/3-night tour by Dau Chan Viet JSC.
Answer ONLY using the tour facts below (itinerary, prices, inclusions, policies, FAQ, contact). If the answer isn't in the facts, say you don't know and suggest calling the hotline or using the booking form.
Reply in ${lang === "en" ? "English" : "Vietnamese"} unless the traveler writes in another language. Keep answers short and clear; use simple bullet lists when helpful.

TOUR FACTS (JSON, each text has vi/en versions):
${JSON.stringify(facts)}`;
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const apiKey = process.env['LOVABLE_API_KEY'];
        if (!apiKey) return Response.json({ error: "AI is not configured." }, { status: 500 });

        let body: { messages?: { role: string; content: string }[]; lang?: string };
        try {
          body = await request.json();
        } catch {
          return Response.json({ error: "Invalid request" }, { status: 400 });
        }
        const messages: ModelMessage[] = (body.messages ?? [])
          .filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
          .slice(-20)
          .map((m) => ({ role: m.role as "user" | "assistant", content: m.content.slice(0, 2000) }));
        if (!messages.length) return Response.json({ error: "No message" }, { status: 400 });

        const runIdFetch = createLovableAiGatewayRunIdFetch(getLovableAiGatewayRunId(request));
        const provider = createOpenAI({
          baseURL: "https://ai.gateway.lovable.dev/v1",
          apiKey,
          headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
          fetch: runIdFetch.fetch,
        });

        let upstreamError: { status: number | undefined; message: string } | null = null;
        const result = streamText({
          model: provider.responses(MODEL) as unknown as Parameters<typeof streamText>[0]["model"],
          instructions: instructions(body.lang ?? "vi"),
          messages,
          abortSignal: request.signal,
          providerOptions: {
            openai: {
              forceReasoning: true,
              reasoningEffort: "low",
              reasoningSummary: "auto",
              store: false,
              include: ["reasoning.encrypted_content"],
            },
          },
          onError: ({ error }) => {
            const e = error as { statusCode?: number; message?: string };
            upstreamError = { status: e.statusCode, message: e.message ?? "AI error" };
            console.error("Tour chat error", e.statusCode, e.message);
          },
        });

        const encoder = new TextEncoder();
        const stream = new ReadableStream({
          async start(controller) {
            try {
              for await (const chunk of result.textStream) controller.enqueue(encoder.encode(chunk));
              if (upstreamError) {
                const s = (upstreamError as { status: number | undefined }).status;
                const msg =
                  s === 429 ? "Too many requests, please try again shortly." :
                  s === 402 ? "AI credits are used up for now." :
                  "The assistant is unavailable right now.";
                controller.enqueue(encoder.encode(`\n\n⚠️ ${msg}`));
              }
            } catch {
              controller.enqueue(encoder.encode("\n\n⚠️ The assistant is unavailable right now."));
            }
            controller.close();
          },
        });

        return withLovableAiGatewayRunIdHeader(
          new Response(stream, { headers: { "Content-Type": "text/plain; charset=utf-8" } }),
          runIdFetch,
        );
      },
    },
  },
});
