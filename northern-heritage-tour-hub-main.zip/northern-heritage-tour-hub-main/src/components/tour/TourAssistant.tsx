import { useRef, useState, useEffect } from "react";
import { useLang } from "@/lib/i18n";

type Msg = { role: "user" | "assistant"; content: string };

const txt = {
  open: { vi: "Hỏi trợ lý tour", en: "Ask the tour assistant" },
  title: { vi: "Trợ lý tour AI", en: "AI tour assistant" },
  hello: {
    vi: "Xin chào! Hỏi tôi bất cứ điều gì về lịch trình, giá và chính sách của tour.",
    en: "Hi! Ask me anything about the itinerary, prices and policies of this tour.",
  },
  placeholder: { vi: "Nhập câu hỏi…", en: "Type your question…" },
  send: { vi: "Gửi", en: "Send" },
  thinking: { vi: "Đang trả lời…", en: "Thinking…" },
  examples: {
    vi: ["Giá cho trẻ 7 tuổi?", "Chính sách huỷ tour?", "Ngày 3 đi đâu?"],
    en: ["Price for a 7-year-old?", "Cancellation policy?", "What happens on Day 3?"],
  },
};

export function TourAssistant() {
  const { lang, t } = useLang();
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [msgs, open]);

  async function send(text: string) {
    const q = text.trim();
    if (!q || busy) return;
    const next: Msg[] = [...msgs, { role: "user", content: q }];
    setMsgs([...next, { role: "assistant", content: "" }]);
    setInput("");
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: next, lang }),
      });
      if (!res.ok || !res.body) throw new Error();
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let acc = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        acc += dec.decode(value, { stream: true });
        setMsgs([...next, { role: "assistant", content: acc }]);
      }
    } catch {
      setMsgs([...next, { role: "assistant", content: lang === "en" ? "⚠️ The assistant is unavailable right now." : "⚠️ Trợ lý tạm thời không khả dụng." }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      {open && (
        <div className="fixed bottom-24 right-4 z-50 flex h-[70vh] max-h-[560px] w-[calc(100vw-2rem)] max-w-sm flex-col overflow-hidden rounded-2xl border border-border bg-card text-card-foreground shadow-glow">
          <div className="flex items-center justify-between bg-primary px-5 py-4 text-primary-foreground">
            <p className="font-display text-lg font-semibold">{t(txt.title)}</p>
            <button onClick={() => setOpen(false)} aria-label="Close" className="text-xl opacity-80 hover:opacity-100">✕</button>
          </div>
          <div className="flex-1 space-y-3 overflow-y-auto p-4 text-sm">
            <p className="rounded-xl bg-secondary p-3">{t(txt.hello)}</p>
            {msgs.length === 0 && (
              <div className="flex flex-wrap gap-2">
                {t(txt.examples).map((e) => (
                  <button key={e} onClick={() => send(e)} className="rounded-full border border-primary px-3 py-1 text-xs text-primary hover:bg-primary hover:text-primary-foreground">{e}</button>
                ))}
              </div>
            )}
            {msgs.map((m, i) => (
              <div key={i} className={`whitespace-pre-wrap rounded-xl p-3 ${m.role === "user" ? "ml-8 bg-primary text-primary-foreground" : "mr-4 bg-secondary"}`}>
                {m.content || <span className="opacity-60">{t(txt.thinking)}</span>}
              </div>
            ))}
            <div ref={endRef} />
          </div>
          <form onSubmit={(e) => { e.preventDefault(); send(input); }} className="flex gap-2 border-t border-border p-3">
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder={t(txt.placeholder)} maxLength={1000}
              className="flex-1 rounded-full border border-input bg-background px-4 py-2 text-sm text-foreground outline-none focus:border-primary" />
            <button disabled={busy || !input.trim()} className="rounded-full bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground disabled:opacity-50">{t(txt.send)}</button>
          </form>
        </div>
      )}
      <button onClick={() => setOpen((o) => !o)} aria-label={t(txt.open)}
        className="fixed bottom-5 right-4 z-50 flex items-center gap-2 rounded-full bg-accent px-5 py-3.5 font-semibold text-accent-foreground shadow-glow transition-transform hover:-translate-y-0.5">
        <span aria-hidden>💬</span><span className="hidden sm:inline">{t(txt.open)}</span>
      </button>
    </>
  );
}
